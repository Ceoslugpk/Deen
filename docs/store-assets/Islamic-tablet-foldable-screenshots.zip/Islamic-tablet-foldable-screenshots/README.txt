ISLAMIC - TABLET AND UNFOLDED FOLDABLE SCREENSHOTS

24 screenshots: 8 per folder, ordered 01-08.

  tablet-7-inch/       1440 x 2560 pixels, portrait 9:16
  tablet-10-inch/      1800 x 3200 pixels, portrait 9:16
  foldable-unfolded/   1840 x 2208 pixels, unfolded 5:6

Each set contains Home (light), Prayer times, Quran home, Quran reader,
Library, Tools, Tasbih and Home (dark).

IMAGE FORMAT
RGB JPEG, quality 95, 4:4:4 chroma, no transparency, under 8 MB each.
Captured at these pixel dimensions; not upscaled or resized phone images.
There are no device frames, marketing overlays or altered UI layouts.

IMPORTANT - CAPTURE METHOD
These are real captures of the running Expo WEB BUILD in Playwright Chromium,
using independently rendered tablet-sized and unfolded-foldable viewports.
They are NOT native Android device or Android emulator screenshots.
Physical diagonal size is not encoded in an image: the inch labels identify
intended listing categories, not a claim that a physical device was used.

The browser used English, Dubai and the Islamic theme. It ran in a fresh,
isolated browser profile. Only onboarding, location and language preferences
were seeded; no personal progress or content API responses were fabricated.
The demonstration clock started at 26 October 2026, 10:10 Dubai time.
All scripture and other content was displayed by the app itself.

Native Android rendering, sensor availability and fold/hinge transitions
are NOT validated by these images. Check the built Android app before using
these as final store-listing evidence for native device support.

UPLOAD NOTES
Unzip first, then select the 8 images in the matching tablet folder in
Play Console. The tablet sets use portrait 9:16 at high resolution.
The foldable set retains the unfolded 5:6 viewport: do not stretch it to fit
a slot that demands 9:16. Use the portrait tablet set for such a slot.

screenshots.csv contains filenames, dimensions and suggested alt text.
capture-manifest.json contains source commit, viewport details, checksums,
image checks and the text used to verify each active screen before capture.

Google's preview asset guidance:
https://support.google.com/googleplay/android-developer/answer/9866151?hl=en
